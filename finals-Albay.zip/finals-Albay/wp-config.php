<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finalsAlbay' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'B-vM4<*g}o4%;,Q,`tB#YICn6%V.(O3md8V^Q~;4U3~HuHL1~ph4Ipz?*sl,/&C0' );
define( 'SECURE_AUTH_KEY',  'N`Tu%jA]~neYb|hSBf{5;DGiz!nIY3JV^75x@bV4`Fm}D$;lFYi/Zjm|to:(&Z+m' );
define( 'LOGGED_IN_KEY',    '>$B>jh q,sAd)9CoSt8Hi35S9=OT5~ug<WbS*.*N<5)0tS{NZl8B5!xl6.$^Kqku' );
define( 'NONCE_KEY',        'p.@.5L:PJv2&6=1[1CY9NC}CxqSvk6K[|YQyDJa:ck.Kuy9bxWQ}1t@uiw{;9h@h' );
define( 'AUTH_SALT',        '>4^mN!e]i#(],U)D<wo(_rzoCEhi,qimH3)NDv> l9To2baL%=Rcgsg$bTDq^N}=' );
define( 'SECURE_AUTH_SALT', 'jwj.i]c=tMFc[F.aiY@6D}Pg`gHFueU^_-nO8$hu3Ci4Gwaul_v##fG;1?%q%F=@' );
define( 'LOGGED_IN_SALT',   '%u#ZZJVQb|5qqJ}:0P>H5ywavS}8RTOy-OLuv-,1&Ro]#-u2!IG$>NH=(7B$.(!e' );
define( 'NONCE_SALT',       '1+A!pvl)B<JucO7HPs# 6DFSFuq$@ep/4Iu/#4sRqXu) }a;y_#}1F!b!<6]F/PU' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
